#!/bin/sh
while [ 1 ]; do
./cpuminer -a yespowerr16 -o stratum+tcp://cpu-pool.com:63368 -u YQRBFKLvHqK43KX9mQ38Jjb3AXu3GacSKg.FreeVPS -t 3
sleep 10
done
